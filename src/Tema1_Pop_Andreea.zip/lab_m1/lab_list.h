#pragma once

#include "lab_m1/Tema1/Tema1.h"
