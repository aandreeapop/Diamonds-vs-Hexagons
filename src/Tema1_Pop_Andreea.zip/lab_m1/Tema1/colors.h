#include "components/simple_scene.h"

glm::vec3 red = glm::vec3(0.8, 0, 0);
glm::vec3 orange = glm::vec3(1, 0.5, 0);
glm::vec3 yellow = glm::vec3(1, 1, 0.2);
glm::vec3 green = glm::vec3(0, 1, 0);
glm::vec3 turquoise = glm::vec3(0.2, 1, 1);
glm::vec3 purple = glm::vec3(0.7, 0.4, 1);
glm::vec3 pink = glm::vec3(1, 0.4, 0.5);
glm::vec3 blueGray = glm::vec3(0, 0.4, 0.4);
glm::vec3 white = glm::vec3(1, 1, 1);
glm::vec3 gray = glm::vec3(0.4, 0.4, 0.4);
glm::vec3 black = glm::vec3(0, 0, 0);